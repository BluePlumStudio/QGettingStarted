#include "QGSILaunchOptionsBuilder.h"

QGSILaunchOptionsBuilder::QGSILaunchOptionsBuilder() :mLaunchOptionsPtr(new QGSLaunchOptions)
{
	
}

QGSILaunchOptionsBuilder::~QGSILaunchOptionsBuilder()
{
}