#include "QGSIAccountFactory.h"

QGSIAccountFactory::QGSIAccountFactory()
{
}

QGSIAccountFactory::~QGSIAccountFactory()
{
}