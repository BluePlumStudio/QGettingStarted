#include <QChar>

#include "QGSILauncher.h"

static const QString SEPARATOR = QGSOperatingSystem::getInstance().getSeparator();

QGSILauncher::QGSILauncher(const QString version, QGSGameDirectory & gameDirectory) :mVersion(version), mGameDirectory(gameDirectory)
{

}

QGSILauncher::~QGSILauncher()
{

}

bool QGSILauncher::isRulesAllowing(const Rules & rules)
{
	bool ret = true;
	auto & instance = QGSOperatingSystem::getInstance();
	auto && osName = instance.getProductType();
	const auto && osVersion = instance.getProductVersion();
	const auto && listRules = rules.getRules();

	if (osName.contains(OS::MACOS))
	{
		//�������json��"osx"��ʾΪ"macos"������
		osName = "os";
	}

	for (auto & i : listRules)
	{
		auto && version = praseOsVersion(i.getOsVersion());

		if (i.getAction() == Action::ALLOW)
		{
			if (i.getOs().contains(osName))
			{
				if (version.isEmpty())
				{
					ret = true;
					break;
				}
				else if (version == osVersion)
				{
					ret = true;
					break;
				}
			}
			else if (i.getOs().isEmpty())
			{
				ret = true;
			}
		}
		else if (i.getAction() == Action::DISALLOW)
		{
			if (i.getOs().contains(osName))
			{
				if (version.isEmpty())
				{
					ret = false;
					break;
				}
				else if (version == osVersion)
				{
					ret = false;
					break;
				}
			}
			else if (i.getOs().isEmpty())
			{
				ret = false;
			}
		}
	}

	return ret;
}

inline QString QGSILauncher::praseOsVersion(QString & osVersion)
{
	if (osVersion.isEmpty())
	{
		return osVersion;
	}

	osVersion.remove("^").remove("\\");

	if (!osVersion.isEmpty() && !(osVersion[osVersion.length() - 1].isNumber()))
	{
		osVersion.remove(osVersion.length() - 1, 1);
	}

	return osVersion;
}
