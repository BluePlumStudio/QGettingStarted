#include "QGSIDownloadSource.h"

QGSIDownloadSource::QGSIDownloadSource(QObject *parent)
	: QObject(parent)
{
}

QGSIDownloadSource::~QGSIDownloadSource()
{
}
