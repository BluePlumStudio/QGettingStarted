#include "QGSIAccount.h"

QGSIAccount::QGSIAccount()
{
}

QGSIAccount::~QGSIAccount()
{
}